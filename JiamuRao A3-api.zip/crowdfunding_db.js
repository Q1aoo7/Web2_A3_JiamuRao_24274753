const mysql = require('mysql2');

const db = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: 'root',
    database: 'crowdfunding_db'
});

// 连接到数据库
db.connect(err => {
    if (err) {
        console.error('MySQL connection error:', err);
        return;
    }
    console.log('Successfully connected to MySQL');
});

// 导出连接
module.exports = db;
